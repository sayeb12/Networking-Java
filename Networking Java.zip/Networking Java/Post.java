
package post;


import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class Post {

    public static void main(String[] args) throws IOException {
        URL url = new URL("https://jsonplaceholder.typicode.com/posts/");
        HttpURLConnection connect = (HttpURLConnection) url.openConnection();
        connect.setRequestMethod("POST");
        connect.setDoOutput(true);
        connect.setRequestProperty("User-Agent", "Chrome");

        OutputStream out = connect.getOutputStream();
        String postedString = "Hi!!! We have posted something!!! Yay!!!";
        out.write(postedString.getBytes());

        int responsecode = connect.getResponseCode();
        System.out.println("The Response Code is:" + responsecode);

        if (responsecode == HttpURLConnection.HTTP_CREATED) {
            InputStreamReader in = new InputStreamReader(connect.getInputStream());
            BufferedReader read = new BufferedReader(in);

            StringBuffer str = new StringBuffer();

            String store = null;
            while ((store = read.readLine()) != null) {
                str.append(store);
            }
            read.close();
            System.out.println("POST Response: " + str);
        }
    }
}
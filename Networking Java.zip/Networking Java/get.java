
package lab_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class Lab_3 {


    public static void main(String[] args) throws IOException {
        URL url = new URL("https://jsonplaceholder.typicode.com/posts/1");
        HttpURLConnection connect = (HttpURLConnection) url.openConnection();
        connect.setRequestMethod("GET");
        connect.setRequestProperty("User-Agent","Chrome");
        
        int responsecode =connect.getResponseCode();
        System.out.println("The Response Code is:" +responsecode);
        
        if(responsecode == HttpURLConnection.HTTP_OK)
        {
            InputStreamReader in = new InputStreamReader(connect.getInputStream());
            BufferedReader read = new BufferedReader(in);
            
            StringBuffer str = new StringBuffer();
            
            String store = null;
            while((store = read.readLine())!=null){
                str.append(store);
            }read.close();
            System.out.println("GET Response" +str);
        }

    }
    
}
